my_host = '127.0.0.1'
server_host = 'http://127.0.0.1:4002'